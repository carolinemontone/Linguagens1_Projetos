/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade1;

/**
 *
 * @author Note-Tiago
 */
public class Dinheiro {
    private double valor;
    private String moeda;
    static private double taxaEuroDolar = 1.0811;
    static private double taxaRealDolar = 3.08;
    
    public double realParaDolar () {
        
        
    }
    
    public double dolarParaReal () {
        
        
    }
    
    public double euroParaDolar () {
        
        
    }
    
    public double dolarParaEuro () {
        
        
    }
    
    public double valorEmReal () {
        
        
    }
    
    public double valorEmDolar () {
        
        
    }
    
    public double valorEmEuro () {
        
    }
    
    public double getTaxaRealDolar () {
        
    }
    
    public double getTaxaEuroDolar () {
        
    }
    
    public double getMoeda () {
        
    }
    
    public boolean setMoeda () {
        
    }
    
    static public boolean alterarTaxaRealDolar () {
        
    }
    
    static public boolean alterarTaxaEuroDolar () {
        
        
    }
    
    
    
    
}
