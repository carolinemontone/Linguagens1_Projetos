/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividade2;

/**
 *
 * * @author Caroline 15.00091-5
 * Adriana 15.00792-8
 */
public interface ICompravel {
    public Pedido criarPedido(Cliente cli);
}
