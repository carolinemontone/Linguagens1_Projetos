package atividadesimulacao;

/**
 *
 * @author Tiago-note
 */
public abstract class Produto {
    
    protected String nome;
    protected Dimensoes dim;
    protected double preco;
    protected boolean necessitaSeguro;

//    public String getNome() {
//        return this.nome;
//    }
//
//    public void setNome(String nome) {
//        this.nome = nome;
//    }

//    public Dimensoes getDim() {
//        return this.dim;
//    }
//
//    public void setDim(Dimensoes dim) {
//        this.dim = dim;
//    }
    
//    public double getPreco() {
//        return this.preco;
//    }
//
//    public void setPreco(double valor) {
//        this.preco = valor;
//    }    
    
}
