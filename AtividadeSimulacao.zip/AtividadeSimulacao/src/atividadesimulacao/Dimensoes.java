/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package atividadesimulacao;

/**
 *
 * @author Tiago-note
 */
public class Dimensoes {
    
    public double altura;
    public double comprimento;
    public double largura;
    public double raio;
    
}
